#Developed by David Neff
#01/11/2025
#This application fulfills requirements for CS210 Module One assignment 1-5 for SNHU Computer Science

#This all that is needed for python to output
#For compiling exe i used pyinstall module. pip install pymodule for its installation. Then from the pycharm terminal, I command pyinstaller moduleOne_python.py --onefile

#Outputing message to console
print("Hello World!")
#adding this input as a pause to read the message
input("Press Enter to close")