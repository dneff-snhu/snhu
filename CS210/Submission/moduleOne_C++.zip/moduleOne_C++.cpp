//Developed by David Neff 
//01/11/2025
//This application fufills requirements for CS210 Module One assignment 1-5 for SNHU Computer Science


//For compiling exe i used MinGW. Then from a terminal intiiated in the directory of my source file, I command g++ -o moduleOne_C++.exe moduleOne_C++.cpp
#include <iostream>
using namespace std;
//Outputing message to console
int main()
{
    //Outputing message to console - added endl so that the 'pause' message would be on the next line
    cout << "Hello World!" << endl;
    //Adding a pause so that the message can be seen
    system("pause");
    //return 0 because the internet sauis it was best practice
    return 0;
}